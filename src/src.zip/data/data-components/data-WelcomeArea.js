import{

    WelcomeAreaIcons1,
    WelcomeAreaIcons2,
    WelcomeAreaIcons3,

} from '../../helpers/allImgs'

const WelcomeAreaInfo = [
    {
        img:WelcomeAreaIcons1,
        history:"Global Transactions",
        text:"Lorem ipsum dolor sit amet adipisicing elit."
    },
    {
        img:WelcomeAreaIcons2,
        history:"24/7 Live Support",
        text:"Lorem ipsum dolor sit amet adipisicing elit."
    },
    {
        img:WelcomeAreaIcons3,
        history:"Stable Reliable",
        text:"Lorem ipsum dolor sit amet adipisicing elit."
    },
]

export default WelcomeAreaInfo