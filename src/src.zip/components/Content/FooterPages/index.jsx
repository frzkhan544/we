import{
  FooterLogo,
} from '../../../helpers/allImgs'
import { NavLink } from 'react-router-dom';
import './Footer.css'

import TextFooter from '../../../data/data-layout/Footer/data-TextFooter.json'

const FooterPages = ({
      text='',
      mt0=false,
      pt100=false
    }) => {

    return (

      <div className={`footer-content-area ${pt100 && "pt-100"} ${mt0 && 'mt-0'}`}>
        <div className="container">
          <div className="row ">
            <div className="col-12 col-lg-4 col-md-6">
              <div className="footer-copywrite-info">
                <div className="copywrite_text fadeInUp" data-wow-delay="0.2s">
                  <div className="footer-logo">
                    <a href="#"><img src={FooterLogo} alt="logo" /> </a>
                  </div>
                  <p>{text}</p>
                  <p style={{color:"white"}}>Copyright © {(new Date().getFullYear())}</p>
                </div>
                
              </div>
            </div>
              {TextFooter && TextFooter.map((item , key) => (
                <div key={key} className={item.classBlock}>
                  <div className="contact_info_area d-sm-flex justify-content-between">
                    <div className={item.classInfo} data-wow-delay="0.3s">
                      <h5>{item.title}</h5>
                      <NavLink className="navbar-link" style={{color:"white"}} activeClassName="is-active" to={item.path1}>{item.text1}</NavLink><br></br>
                      <NavLink className="navbar-link" style={{color:"white"}} activeClassName="is-active" to={item.path2}>{item.text2}</NavLink><br></br>
                      <NavLink className="navbar-link" style={{color:"white"}} activeClassName="is-active" to={item.path3}>{item.text3}</NavLink><br></br>
                      <NavLink className="navbar-link" style={{color:"white"}} activeClassName="is-active" to={item.path4}>{item.text4}</NavLink><br></br>
                      {item.text5 && <a href={item.path5}><p>{item.text5}</p></a>}
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    );

}

export default FooterPages