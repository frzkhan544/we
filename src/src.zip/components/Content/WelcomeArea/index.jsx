import "./welcome.css"

const WelcomeArea = ({
    ClassSec,
    welcomeContClass,
    specialHeadClass,
    text,
    ClassTitle,
    title,
    ClassDummyText="",
    dummyText,
    addRow=false
  }) => {

    return (

      <section className={ClassSec} id="home">
  
        <div className="overlay" />
        <div className="hero-section-content">
          <div className="container ">
            <div className="row align-items-center">
              <div className="col-12 col-lg-6 col-md-12">
                <div className={welcomeContClass}>
                  <div className="promo-section">
                    <h3 className={specialHeadClass}>{text}</h3>
                  </div>
                  <h1 className={ClassTitle} data-wow-delay="0.2s">{title}</h1>
                  <p className={ClassDummyText} data-wow-delay="0.3s">{dummyText}</p>
                  <div className="info-btn-group fadeInUp" data-wow-delay="0.4s">
                    <a href="#explore" className="btn info-btn">Explore</a>
                    <a href="#mint" className="btn info-btn ml-30">Create</a>
                  </div>
                </div>
                

              </div>
              <div className="col-12 col-lg-6 col-md-12">
              </div>
            </div>
          </div>
        </div>
      </section>
    );

}

export default WelcomeArea